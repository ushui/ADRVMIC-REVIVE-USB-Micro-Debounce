namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��1",
            "�}�E�X",
            "���N���b�N"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��2"}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��3"}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��4"}, -1);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��5"}, -1);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��6"}, -1);
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��7"}, -1);
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��8"}, -1);
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��9"}, -1);
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��10"}, -1);
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��11"}, -1);
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem(new string[] {
            "",
            "�{�^��12"}, -1);
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem21 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem22 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem23 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem24 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem25 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem26 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem27 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem28 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem29 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem30 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem31 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem32 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem33 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem34 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem35 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem36 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.KeyboardValue_txtbx = new System.Windows.Forms.TextBox();
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.MouseMove_UD = new System.Windows.Forms.NumericUpDown();
            this.Button12_cbox = new System.Windows.Forms.CheckBox();
            this.Button11_cbox = new System.Windows.Forms.CheckBox();
            this.Button10_cbox = new System.Windows.Forms.CheckBox();
            this.Button9_cbox = new System.Windows.Forms.CheckBox();
            this.Button8_cbox = new System.Windows.Forms.CheckBox();
            this.Button7_cbox = new System.Windows.Forms.CheckBox();
            this.SetPin_combox = new System.Windows.Forms.ComboBox();
            this.Button6_cbox = new System.Windows.Forms.CheckBox();
            this.Button5_cbox = new System.Windows.Forms.CheckBox();
            this.Button4_cbox = new System.Windows.Forms.CheckBox();
            this.Button3_cbox = new System.Windows.Forms.CheckBox();
            this.Button2_cbox = new System.Windows.Forms.CheckBox();
            this.Button1_cbox = new System.Windows.Forms.CheckBox();
            this.LeverRight_cbox = new System.Windows.Forms.CheckBox();
            this.LeverLeft_cbox = new System.Windows.Forms.CheckBox();
            this.LeverDown_cbox = new System.Windows.Forms.CheckBox();
            this.LeverUp_cbox = new System.Windows.Forms.CheckBox();
            this.Win_cbox = new System.Windows.Forms.CheckBox();
            this.Shift_cbox = new System.Windows.Forms.CheckBox();
            this.Alt_cbox = new System.Windows.Forms.CheckBox();
            this.Ctrl_cbox = new System.Windows.Forms.CheckBox();
            this.mousevalue_combx = new System.Windows.Forms.ComboBox();
            this.devicetype_combox = new System.Windows.Forms.ComboBox();
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.Button_list = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.update_btn = new System.Windows.Forms.Button();
            this.SW36B_pb = new System.Windows.Forms.PictureBox();
            this.SW35B_pb = new System.Windows.Forms.PictureBox();
            this.SW34B_pb = new System.Windows.Forms.PictureBox();
            this.SW33B_pb = new System.Windows.Forms.PictureBox();
            this.SW32B_pb = new System.Windows.Forms.PictureBox();
            this.SW31B_pb = new System.Windows.Forms.PictureBox();
            this.SW30B_pb = new System.Windows.Forms.PictureBox();
            this.SW29B_pb = new System.Windows.Forms.PictureBox();
            this.SW28B_pb = new System.Windows.Forms.PictureBox();
            this.SW27B_pb = new System.Windows.Forms.PictureBox();
            this.SW26B_pb = new System.Windows.Forms.PictureBox();
            this.SW25B_pb = new System.Windows.Forms.PictureBox();
            this.SW24B_pb = new System.Windows.Forms.PictureBox();
            this.SW23B_pb = new System.Windows.Forms.PictureBox();
            this.SW22B_pb = new System.Windows.Forms.PictureBox();
            this.SW21B_pb = new System.Windows.Forms.PictureBox();
            this.SW20B_pb = new System.Windows.Forms.PictureBox();
            this.SW19B_pb = new System.Windows.Forms.PictureBox();
            this.SW18B_pb = new System.Windows.Forms.PictureBox();
            this.SW17B_pb = new System.Windows.Forms.PictureBox();
            this.SW16B_pb = new System.Windows.Forms.PictureBox();
            this.SW15B_pb = new System.Windows.Forms.PictureBox();
            this.SW14B_pb = new System.Windows.Forms.PictureBox();
            this.SW13B_pb = new System.Windows.Forms.PictureBox();
            this.SW12B_pb = new System.Windows.Forms.PictureBox();
            this.SW11B_pb = new System.Windows.Forms.PictureBox();
            this.SW10B_pb = new System.Windows.Forms.PictureBox();
            this.SW09B_pb = new System.Windows.Forms.PictureBox();
            this.SW08B_pb = new System.Windows.Forms.PictureBox();
            this.SW07B_pb = new System.Windows.Forms.PictureBox();
            this.SW06B_pb = new System.Windows.Forms.PictureBox();
            this.SW05B_pb = new System.Windows.Forms.PictureBox();
            this.SW04B_pb = new System.Windows.Forms.PictureBox();
            this.SW03B_pb = new System.Windows.Forms.PictureBox();
            this.SW02B_pb = new System.Windows.Forms.PictureBox();
            this.SW01B_pb = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon36 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon35 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon34 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon33 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon32 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon31 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon30 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon29 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon28 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon27 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon26 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon25 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon24 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon23 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon22 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon21 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon20 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon19 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon18 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon17 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon16 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon15 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon14 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon13 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon12 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon11 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon10 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon9 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon8 = new System.Windows.Forms.PictureBox();
            this.Arrow_Mouse3_pb = new System.Windows.Forms.PictureBox();
            this.Speed_Mouse5_pb = new System.Windows.Forms.PictureBox();
            this.Arrow_Mouse2_pb = new System.Windows.Forms.PictureBox();
            this.Speed_Mouse4_pb = new System.Windows.Forms.PictureBox();
            this.Arrow_Mouse1_pb = new System.Windows.Forms.PictureBox();
            this.Pin02B_pb = new System.Windows.Forms.PictureBox();
            this.Pin03B_pb = new System.Windows.Forms.PictureBox();
            this.Pin04B_pb = new System.Windows.Forms.PictureBox();
            this.Pin01B_pb = new System.Windows.Forms.PictureBox();
            this.Pin05B_pb = new System.Windows.Forms.PictureBox();
            this.Pin06B_pb = new System.Windows.Forms.PictureBox();
            this.Pin07B_pb = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.Arrow_Com_pb = new System.Windows.Forms.PictureBox();
            this.Arrow_Keyboard_pb = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon5 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon6 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon7 = new System.Windows.Forms.PictureBox();
            this.Changevalue_btn = new System.Windows.Forms.Button();
            this.ButtonPressIcon4 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon3 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon2 = new System.Windows.Forms.PictureBox();
            this.ButtonPressIcon1 = new System.Windows.Forms.PictureBox();
            this.Pin08B_pb = new System.Windows.Forms.PictureBox();
            this.Pin09B_pb = new System.Windows.Forms.PictureBox();
            this.Pin10B_pb = new System.Windows.Forms.PictureBox();
            this.Pin11B_pb = new System.Windows.Forms.PictureBox();
            this.Pin12B_pb = new System.Windows.Forms.PictureBox();
            this.BackGround = new System.Windows.Forms.PictureBox();
            this.lbl_FWVersion = new System.Windows.Forms.Label();
            this.AllButtonSetting_grpbox = new System.Windows.Forms.GroupBox();
            this.check_count_numUpDown = new System.Windows.Forms.NumericUpDown();
            this.smpl_interval_numUpDown = new System.Windows.Forms.NumericUpDown();
            this.lbl_delay_calc_result = new System.Windows.Forms.Label();
            this.lbl_delay_calc = new System.Windows.Forms.Label();
            this.check_count_lbl = new System.Windows.Forms.Label();
            this.check_count_desc_lbl = new System.Windows.Forms.Label();
            this.smpl_interval_lbl = new System.Windows.Forms.Label();
            this.smpl_interval_desc_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MouseMove_UD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW36B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW35B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW34B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW33B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW32B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW31B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW30B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW29B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW28B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW27B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW26B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW25B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW24B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW23B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW22B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW21B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW20B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW19B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW18B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW17B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW16B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW15B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW14B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW13B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW12B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW11B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW10B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW09B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW08B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW07B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW06B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW05B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW04B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW03B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW02B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW01B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse3_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Speed_Mouse5_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse2_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Speed_Mouse4_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse1_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin02B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin03B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin04B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin01B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin05B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin06B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin07B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Com_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Keyboard_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin08B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin09B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin10B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin11B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin12B_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BackGround)).BeginInit();
            this.AllButtonSetting_grpbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.check_count_numUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smpl_interval_numUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // KeyboardValue_txtbx
            // 
            this.KeyboardValue_txtbx.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.KeyboardValue_txtbx.Location = new System.Drawing.Point(64, 333);
            this.KeyboardValue_txtbx.Name = "KeyboardValue_txtbx";
            this.KeyboardValue_txtbx.Size = new System.Drawing.Size(100, 19);
            this.KeyboardValue_txtbx.TabIndex = 31;
            this.KeyboardValue_txtbx.Text = "�����ɓ���";
            this.KeyboardValue_txtbx.Visible = false;
            this.KeyboardValue_txtbx.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyboardValue_txtbx_KeyDown);
            this.KeyboardValue_txtbx.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyboardValue_txtbx_KeyUp);
            this.KeyboardValue_txtbx.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.KeyboardValue_txtbx_PreviewKeyDown);
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // MouseMove_UD
            // 
            this.MouseMove_UD.BackColor = System.Drawing.SystemColors.Window;
            this.MouseMove_UD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.MouseMove_UD.Location = new System.Drawing.Point(53, 255);
            this.MouseMove_UD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.MouseMove_UD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.MouseMove_UD.Name = "MouseMove_UD";
            this.MouseMove_UD.Size = new System.Drawing.Size(128, 19);
            this.MouseMove_UD.TabIndex = 86;
            this.MouseMove_UD.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.MouseMove_UD.Visible = false;
            this.MouseMove_UD.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // Button12_cbox
            // 
            this.Button12_cbox.AutoSize = true;
            this.Button12_cbox.BackColor = System.Drawing.Color.White;
            this.Button12_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button12_cbox.Location = new System.Drawing.Point(119, 349);
            this.Button12_cbox.Name = "Button12_cbox";
            this.Button12_cbox.Size = new System.Drawing.Size(67, 16);
            this.Button12_cbox.TabIndex = 82;
            this.Button12_cbox.Text = "�{�^���P�Q";
            this.Button12_cbox.UseVisualStyleBackColor = false;
            this.Button12_cbox.Visible = false;
            this.Button12_cbox.CheckedChanged += new System.EventHandler(this.Button12_cbox_CheckedChanged);
            // 
            // Button11_cbox
            // 
            this.Button11_cbox.AutoSize = true;
            this.Button11_cbox.BackColor = System.Drawing.Color.White;
            this.Button11_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button11_cbox.Location = new System.Drawing.Point(119, 328);
            this.Button11_cbox.Name = "Button11_cbox";
            this.Button11_cbox.Size = new System.Drawing.Size(67, 16);
            this.Button11_cbox.TabIndex = 81;
            this.Button11_cbox.Text = "�{�^���P�P";
            this.Button11_cbox.UseVisualStyleBackColor = false;
            this.Button11_cbox.Visible = false;
            this.Button11_cbox.CheckedChanged += new System.EventHandler(this.Button11_cbox_CheckedChanged);
            // 
            // Button10_cbox
            // 
            this.Button10_cbox.AutoSize = true;
            this.Button10_cbox.BackColor = System.Drawing.Color.White;
            this.Button10_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button10_cbox.Location = new System.Drawing.Point(119, 307);
            this.Button10_cbox.Name = "Button10_cbox";
            this.Button10_cbox.Size = new System.Drawing.Size(67, 16);
            this.Button10_cbox.TabIndex = 80;
            this.Button10_cbox.Text = "�{�^���P�O";
            this.Button10_cbox.UseVisualStyleBackColor = false;
            this.Button10_cbox.Visible = false;
            this.Button10_cbox.CheckedChanged += new System.EventHandler(this.Button10_cbox_CheckedChanged);
            // 
            // Button9_cbox
            // 
            this.Button9_cbox.AutoSize = true;
            this.Button9_cbox.BackColor = System.Drawing.Color.Transparent;
            this.Button9_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button9_cbox.Location = new System.Drawing.Point(119, 287);
            this.Button9_cbox.Name = "Button9_cbox";
            this.Button9_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button9_cbox.TabIndex = 79;
            this.Button9_cbox.Text = "�{�^���X";
            this.Button9_cbox.UseVisualStyleBackColor = false;
            this.Button9_cbox.Visible = false;
            this.Button9_cbox.CheckedChanged += new System.EventHandler(this.Button9_cbox_CheckedChanged);
            // 
            // Button8_cbox
            // 
            this.Button8_cbox.AutoSize = true;
            this.Button8_cbox.BackColor = System.Drawing.Color.Transparent;
            this.Button8_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button8_cbox.Location = new System.Drawing.Point(119, 265);
            this.Button8_cbox.Name = "Button8_cbox";
            this.Button8_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button8_cbox.TabIndex = 78;
            this.Button8_cbox.Text = "�{�^���W";
            this.Button8_cbox.UseVisualStyleBackColor = false;
            this.Button8_cbox.Visible = false;
            this.Button8_cbox.CheckedChanged += new System.EventHandler(this.Button8_cbox_CheckedChanged);
            // 
            // Button7_cbox
            // 
            this.Button7_cbox.AutoSize = true;
            this.Button7_cbox.BackColor = System.Drawing.Color.White;
            this.Button7_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button7_cbox.Location = new System.Drawing.Point(119, 244);
            this.Button7_cbox.Name = "Button7_cbox";
            this.Button7_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button7_cbox.TabIndex = 77;
            this.Button7_cbox.Text = "�{�^���V";
            this.Button7_cbox.UseVisualStyleBackColor = false;
            this.Button7_cbox.Visible = false;
            this.Button7_cbox.CheckedChanged += new System.EventHandler(this.Button7_cbox_CheckedChanged);
            // 
            // SetPin_combox
            // 
            this.SetPin_combox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SetPin_combox.Enabled = false;
            this.SetPin_combox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.SetPin_combox.FormattingEnabled = true;
            this.SetPin_combox.ItemHeight = 12;
            this.SetPin_combox.Items.AddRange(new object[] {
            "�{�^��1",
            "�{�^��2",
            "�{�^��3",
            "�{�^��4",
            "�{�^��5",
            "�{�^��6",
            "�{�^��7",
            "�{�^��8",
            "�{�^��9",
            "�{�^��10",
            "�{�^��11",
            "�{�^��12",
            "�{�^��13",
            "�{�^��14",
            "�{�^��15",
            "�{�^��16",
            "�{�^��17",
            "�{�^��18",
            "�{�^��19",
            "�{�^��20",
            "�{�^��21",
            "�{�^��22",
            "�{�^��23",
            "�{�^��24",
            "�{�^��25",
            "�{�^��26",
            "�{�^��27",
            "�{�^��28",
            "�{�^��29",
            "�{�^��30",
            "�{�^��31",
            "�{�^��32",
            "�{�^��33",
            "�{�^��34",
            "�{�^��35",
            "�{�^��36"});
            this.SetPin_combox.Location = new System.Drawing.Point(53, 82);
            this.SetPin_combox.MaxDropDownItems = 12;
            this.SetPin_combox.Name = "SetPin_combox";
            this.SetPin_combox.Size = new System.Drawing.Size(121, 20);
            this.SetPin_combox.TabIndex = 46;
            this.SetPin_combox.SelectedIndexChanged += new System.EventHandler(this.SetPin_combox_SelectedIndexChanged);
            // 
            // Button6_cbox
            // 
            this.Button6_cbox.AutoSize = true;
            this.Button6_cbox.BackColor = System.Drawing.Color.White;
            this.Button6_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button6_cbox.Location = new System.Drawing.Point(119, 223);
            this.Button6_cbox.Name = "Button6_cbox";
            this.Button6_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button6_cbox.TabIndex = 45;
            this.Button6_cbox.Text = "�{�^���U";
            this.Button6_cbox.UseVisualStyleBackColor = false;
            this.Button6_cbox.Visible = false;
            this.Button6_cbox.CheckedChanged += new System.EventHandler(this.Button6_cbox_CheckedChanged);
            // 
            // Button5_cbox
            // 
            this.Button5_cbox.AutoSize = true;
            this.Button5_cbox.BackColor = System.Drawing.Color.White;
            this.Button5_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button5_cbox.Location = new System.Drawing.Point(119, 202);
            this.Button5_cbox.Name = "Button5_cbox";
            this.Button5_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button5_cbox.TabIndex = 44;
            this.Button5_cbox.Text = "�{�^���T";
            this.Button5_cbox.UseVisualStyleBackColor = false;
            this.Button5_cbox.Visible = false;
            this.Button5_cbox.CheckedChanged += new System.EventHandler(this.Button5_cbox_CheckedChanged);
            // 
            // Button4_cbox
            // 
            this.Button4_cbox.AutoSize = true;
            this.Button4_cbox.BackColor = System.Drawing.Color.White;
            this.Button4_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button4_cbox.Location = new System.Drawing.Point(52, 349);
            this.Button4_cbox.Name = "Button4_cbox";
            this.Button4_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button4_cbox.TabIndex = 43;
            this.Button4_cbox.Text = "�{�^���S";
            this.Button4_cbox.UseVisualStyleBackColor = false;
            this.Button4_cbox.Visible = false;
            this.Button4_cbox.CheckedChanged += new System.EventHandler(this.Button4_cbox_CheckedChanged);
            // 
            // Button3_cbox
            // 
            this.Button3_cbox.AutoSize = true;
            this.Button3_cbox.BackColor = System.Drawing.Color.White;
            this.Button3_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button3_cbox.Location = new System.Drawing.Point(52, 328);
            this.Button3_cbox.Name = "Button3_cbox";
            this.Button3_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button3_cbox.TabIndex = 42;
            this.Button3_cbox.Text = "�{�^���R";
            this.Button3_cbox.UseVisualStyleBackColor = false;
            this.Button3_cbox.Visible = false;
            this.Button3_cbox.CheckedChanged += new System.EventHandler(this.Button3_cbox_CheckedChanged);
            // 
            // Button2_cbox
            // 
            this.Button2_cbox.AutoSize = true;
            this.Button2_cbox.BackColor = System.Drawing.Color.White;
            this.Button2_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button2_cbox.Location = new System.Drawing.Point(52, 307);
            this.Button2_cbox.Name = "Button2_cbox";
            this.Button2_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button2_cbox.TabIndex = 41;
            this.Button2_cbox.Text = "�{�^���Q";
            this.Button2_cbox.UseVisualStyleBackColor = false;
            this.Button2_cbox.Visible = false;
            this.Button2_cbox.CheckedChanged += new System.EventHandler(this.Button2_cbox_CheckedChanged);
            // 
            // Button1_cbox
            // 
            this.Button1_cbox.AutoSize = true;
            this.Button1_cbox.BackColor = System.Drawing.Color.White;
            this.Button1_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button1_cbox.Location = new System.Drawing.Point(52, 286);
            this.Button1_cbox.Name = "Button1_cbox";
            this.Button1_cbox.Size = new System.Drawing.Size(59, 16);
            this.Button1_cbox.TabIndex = 40;
            this.Button1_cbox.Text = "�{�^���P";
            this.Button1_cbox.UseVisualStyleBackColor = false;
            this.Button1_cbox.Visible = false;
            this.Button1_cbox.CheckedChanged += new System.EventHandler(this.Button1_cbox_CheckedChanged);
            // 
            // LeverRight_cbox
            // 
            this.LeverRight_cbox.AutoSize = true;
            this.LeverRight_cbox.BackColor = System.Drawing.Color.Transparent;
            this.LeverRight_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.LeverRight_cbox.Location = new System.Drawing.Point(52, 265);
            this.LeverRight_cbox.Name = "LeverRight_cbox";
            this.LeverRight_cbox.Size = new System.Drawing.Size(65, 16);
            this.LeverRight_cbox.TabIndex = 39;
            this.LeverRight_cbox.Text = "���o�[�E";
            this.LeverRight_cbox.UseVisualStyleBackColor = false;
            this.LeverRight_cbox.Visible = false;
            this.LeverRight_cbox.CheckedChanged += new System.EventHandler(this.LeverRight_cbox_CheckedChanged);
            // 
            // LeverLeft_cbox
            // 
            this.LeverLeft_cbox.AutoSize = true;
            this.LeverLeft_cbox.BackColor = System.Drawing.Color.White;
            this.LeverLeft_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.LeverLeft_cbox.Location = new System.Drawing.Point(52, 244);
            this.LeverLeft_cbox.Name = "LeverLeft_cbox";
            this.LeverLeft_cbox.Size = new System.Drawing.Size(65, 16);
            this.LeverLeft_cbox.TabIndex = 38;
            this.LeverLeft_cbox.Text = "���o�[��";
            this.LeverLeft_cbox.UseVisualStyleBackColor = false;
            this.LeverLeft_cbox.Visible = false;
            this.LeverLeft_cbox.CheckedChanged += new System.EventHandler(this.LeverLeft_cbox_CheckedChanged);
            // 
            // LeverDown_cbox
            // 
            this.LeverDown_cbox.AutoSize = true;
            this.LeverDown_cbox.BackColor = System.Drawing.Color.White;
            this.LeverDown_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.LeverDown_cbox.Location = new System.Drawing.Point(52, 223);
            this.LeverDown_cbox.Name = "LeverDown_cbox";
            this.LeverDown_cbox.Size = new System.Drawing.Size(65, 16);
            this.LeverDown_cbox.TabIndex = 37;
            this.LeverDown_cbox.Text = "���o�[��";
            this.LeverDown_cbox.UseVisualStyleBackColor = false;
            this.LeverDown_cbox.Visible = false;
            this.LeverDown_cbox.CheckedChanged += new System.EventHandler(this.LeverDown_cbox_CheckedChanged);
            // 
            // LeverUp_cbox
            // 
            this.LeverUp_cbox.AutoSize = true;
            this.LeverUp_cbox.BackColor = System.Drawing.Color.White;
            this.LeverUp_cbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.LeverUp_cbox.Location = new System.Drawing.Point(52, 202);
            this.LeverUp_cbox.Name = "LeverUp_cbox";
            this.LeverUp_cbox.Size = new System.Drawing.Size(65, 16);
            this.LeverUp_cbox.TabIndex = 36;
            this.LeverUp_cbox.Text = "���o�[��";
            this.LeverUp_cbox.UseVisualStyleBackColor = false;
            this.LeverUp_cbox.Visible = false;
            this.LeverUp_cbox.CheckedChanged += new System.EventHandler(this.LeverUp_cbox_CheckedChanged);
            // 
            // Win_cbox
            // 
            this.Win_cbox.AutoSize = true;
            this.Win_cbox.Location = new System.Drawing.Point(93, 270);
            this.Win_cbox.Name = "Win_cbox";
            this.Win_cbox.Size = new System.Drawing.Size(42, 16);
            this.Win_cbox.TabIndex = 35;
            this.Win_cbox.Text = "Win";
            this.Win_cbox.UseVisualStyleBackColor = true;
            this.Win_cbox.Visible = false;
            this.Win_cbox.CheckedChanged += new System.EventHandler(this.Win_cbox_CheckedChanged);
            // 
            // Shift_cbox
            // 
            this.Shift_cbox.AutoSize = true;
            this.Shift_cbox.Location = new System.Drawing.Point(93, 228);
            this.Shift_cbox.Name = "Shift_cbox";
            this.Shift_cbox.Size = new System.Drawing.Size(48, 16);
            this.Shift_cbox.TabIndex = 34;
            this.Shift_cbox.Text = "Shift";
            this.Shift_cbox.UseVisualStyleBackColor = true;
            this.Shift_cbox.Visible = false;
            this.Shift_cbox.CheckedChanged += new System.EventHandler(this.Shift_cbox_CheckedChanged);
            // 
            // Alt_cbox
            // 
            this.Alt_cbox.AutoSize = true;
            this.Alt_cbox.Location = new System.Drawing.Point(93, 249);
            this.Alt_cbox.Name = "Alt_cbox";
            this.Alt_cbox.Size = new System.Drawing.Size(39, 16);
            this.Alt_cbox.TabIndex = 33;
            this.Alt_cbox.Text = "Alt";
            this.Alt_cbox.UseVisualStyleBackColor = true;
            this.Alt_cbox.Visible = false;
            this.Alt_cbox.CheckedChanged += new System.EventHandler(this.Alt_cbox_CheckedChanged);
            // 
            // Ctrl_cbox
            // 
            this.Ctrl_cbox.AutoSize = true;
            this.Ctrl_cbox.Location = new System.Drawing.Point(93, 207);
            this.Ctrl_cbox.Name = "Ctrl_cbox";
            this.Ctrl_cbox.Size = new System.Drawing.Size(43, 16);
            this.Ctrl_cbox.TabIndex = 32;
            this.Ctrl_cbox.Text = "Ctrl";
            this.Ctrl_cbox.UseVisualStyleBackColor = true;
            this.Ctrl_cbox.Visible = false;
            this.Ctrl_cbox.CheckedChanged += new System.EventHandler(this.Ctrl_cbox_CheckedChanged);
            // 
            // mousevalue_combx
            // 
            this.mousevalue_combx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mousevalue_combx.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.mousevalue_combx.FormattingEnabled = true;
            this.mousevalue_combx.Items.AddRange(new object[] {
            "���N���b�N",
            "�E�N���b�N",
            "�z�C�[���N���b�N",
            "��ړ�",
            "���ړ�",
            "���ړ�",
            "�E�ړ�",
            "�z�C�[����",
            "�z�C�[����",
            "�J�[�\�����x�ύX"});
            this.mousevalue_combx.Location = new System.Drawing.Point(53, 198);
            this.mousevalue_combx.Name = "mousevalue_combx";
            this.mousevalue_combx.Size = new System.Drawing.Size(121, 20);
            this.mousevalue_combx.TabIndex = 26;
            this.mousevalue_combx.Visible = false;
            this.mousevalue_combx.SelectedIndexChanged += new System.EventHandler(this.mousevalue_combx_SelectedIndexChanged);
            // 
            // devicetype_combox
            // 
            this.devicetype_combox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.devicetype_combox.Enabled = false;
            this.devicetype_combox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.devicetype_combox.FormattingEnabled = true;
            this.devicetype_combox.Items.AddRange(new object[] {
            "�}�E�X",
            "�L�[�{�[�h",
            "�W���C�p�b�h"});
            this.devicetype_combox.Location = new System.Drawing.Point(53, 140);
            this.devicetype_combox.Name = "devicetype_combox";
            this.devicetype_combox.Size = new System.Drawing.Size(121, 20);
            this.devicetype_combox.TabIndex = 25;
            this.devicetype_combox.SelectedIndexChanged += new System.EventHandler(this.devicetype_combox_SelectedIndexChanged);
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.Color.Transparent;
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(756, 487);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 117;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.Transparent;
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(18, 487);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(319, 12);
            this.StatusBox_lbl2.TabIndex = 118;
            this.StatusBox_lbl2.Text = "REVIVE USB MICRO MATRIX, Configuration Tool�N�����܂���";
            // 
            // Button_list
            // 
            this.Button_list.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(222)))), ((int)(((byte)(222)))));
            this.Button_list.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.Button_list.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.Button_list.FullRowSelect = true;
            this.Button_list.GridLines = true;
            this.Button_list.HideSelection = false;
            this.Button_list.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13,
            listViewItem14,
            listViewItem15,
            listViewItem16,
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20,
            listViewItem21,
            listViewItem22,
            listViewItem23,
            listViewItem24,
            listViewItem25,
            listViewItem26,
            listViewItem27,
            listViewItem28,
            listViewItem29,
            listViewItem30,
            listViewItem31,
            listViewItem32,
            listViewItem33,
            listViewItem34,
            listViewItem35,
            listViewItem36});
            this.Button_list.Location = new System.Drawing.Point(659, 46);
            this.Button_list.MultiSelect = false;
            this.Button_list.Name = "Button_list";
            this.Button_list.Size = new System.Drawing.Size(211, 330);
            this.Button_list.TabIndex = 163;
            this.Button_list.UseCompatibleStateImageBehavior = false;
            this.Button_list.View = System.Windows.Forms.View.Details;
            this.Button_list.SelectedIndexChanged += new System.EventHandler(this.Button_list_SelectedIndexChanged);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "ID";
            this.columnHeader4.Width = 3;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "����No";
            this.columnHeader1.Width = 51;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "���޲�����";
            this.columnHeader2.Width = 71;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "������";
            this.columnHeader3.Width = 408;
            // 
            // update_btn
            // 
            this.update_btn.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.update_btn.Location = new System.Drawing.Point(215, 395);
            this.update_btn.Name = "update_btn";
            this.update_btn.Size = new System.Drawing.Size(75, 23);
            this.update_btn.TabIndex = 297;
            this.update_btn.Text = "Update";
            this.update_btn.UseVisualStyleBackColor = false;
            this.update_btn.Click += new System.EventHandler(this.update_btn_Click);
            // 
            // SW36B_pb
            // 
            this.SW36B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW36B_pb.Location = new System.Drawing.Point(606, 353);
            this.SW36B_pb.Name = "SW36B_pb";
            this.SW36B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW36B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW36B_pb.TabIndex = 259;
            this.SW36B_pb.TabStop = false;
            this.SW36B_pb.Click += new System.EventHandler(this.SW36B_pb_Click);
            // 
            // SW35B_pb
            // 
            this.SW35B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW35B_pb.Location = new System.Drawing.Point(606, 297);
            this.SW35B_pb.Name = "SW35B_pb";
            this.SW35B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW35B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW35B_pb.TabIndex = 258;
            this.SW35B_pb.TabStop = false;
            this.SW35B_pb.Click += new System.EventHandler(this.SW35B_pb_Click);
            // 
            // SW34B_pb
            // 
            this.SW34B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW34B_pb.Location = new System.Drawing.Point(606, 241);
            this.SW34B_pb.Name = "SW34B_pb";
            this.SW34B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW34B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW34B_pb.TabIndex = 257;
            this.SW34B_pb.TabStop = false;
            this.SW34B_pb.Click += new System.EventHandler(this.SW34B_pb_Click);
            // 
            // SW33B_pb
            // 
            this.SW33B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW33B_pb.Location = new System.Drawing.Point(606, 185);
            this.SW33B_pb.Name = "SW33B_pb";
            this.SW33B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW33B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW33B_pb.TabIndex = 256;
            this.SW33B_pb.TabStop = false;
            this.SW33B_pb.Click += new System.EventHandler(this.SW33B_pb_Click);
            // 
            // SW32B_pb
            // 
            this.SW32B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW32B_pb.Location = new System.Drawing.Point(606, 129);
            this.SW32B_pb.Name = "SW32B_pb";
            this.SW32B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW32B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW32B_pb.TabIndex = 255;
            this.SW32B_pb.TabStop = false;
            this.SW32B_pb.Click += new System.EventHandler(this.SW32B_pb_Click);
            // 
            // SW31B_pb
            // 
            this.SW31B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW31B_pb.Location = new System.Drawing.Point(606, 73);
            this.SW31B_pb.Name = "SW31B_pb";
            this.SW31B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW31B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW31B_pb.TabIndex = 254;
            this.SW31B_pb.TabStop = false;
            this.SW31B_pb.Click += new System.EventHandler(this.SW31B_pb_Click);
            // 
            // SW30B_pb
            // 
            this.SW30B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW30B_pb.Location = new System.Drawing.Point(543, 353);
            this.SW30B_pb.Name = "SW30B_pb";
            this.SW30B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW30B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW30B_pb.TabIndex = 253;
            this.SW30B_pb.TabStop = false;
            this.SW30B_pb.Click += new System.EventHandler(this.SW30B_pb_Click);
            // 
            // SW29B_pb
            // 
            this.SW29B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW29B_pb.Location = new System.Drawing.Point(543, 297);
            this.SW29B_pb.Name = "SW29B_pb";
            this.SW29B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW29B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW29B_pb.TabIndex = 252;
            this.SW29B_pb.TabStop = false;
            this.SW29B_pb.Click += new System.EventHandler(this.SW29B_pb_Click);
            // 
            // SW28B_pb
            // 
            this.SW28B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW28B_pb.Location = new System.Drawing.Point(543, 241);
            this.SW28B_pb.Name = "SW28B_pb";
            this.SW28B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW28B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW28B_pb.TabIndex = 251;
            this.SW28B_pb.TabStop = false;
            this.SW28B_pb.Click += new System.EventHandler(this.SW28B_pb_Click);
            // 
            // SW27B_pb
            // 
            this.SW27B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW27B_pb.Location = new System.Drawing.Point(543, 185);
            this.SW27B_pb.Name = "SW27B_pb";
            this.SW27B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW27B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW27B_pb.TabIndex = 250;
            this.SW27B_pb.TabStop = false;
            this.SW27B_pb.Click += new System.EventHandler(this.SW27B_pb_Click);
            // 
            // SW26B_pb
            // 
            this.SW26B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW26B_pb.Location = new System.Drawing.Point(543, 129);
            this.SW26B_pb.Name = "SW26B_pb";
            this.SW26B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW26B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW26B_pb.TabIndex = 249;
            this.SW26B_pb.TabStop = false;
            this.SW26B_pb.Click += new System.EventHandler(this.SW26B_pb_Click);
            // 
            // SW25B_pb
            // 
            this.SW25B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW25B_pb.Location = new System.Drawing.Point(543, 73);
            this.SW25B_pb.Name = "SW25B_pb";
            this.SW25B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW25B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW25B_pb.TabIndex = 248;
            this.SW25B_pb.TabStop = false;
            this.SW25B_pb.Click += new System.EventHandler(this.SW25B_pb_Click);
            // 
            // SW24B_pb
            // 
            this.SW24B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW24B_pb.Location = new System.Drawing.Point(480, 353);
            this.SW24B_pb.Name = "SW24B_pb";
            this.SW24B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW24B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW24B_pb.TabIndex = 247;
            this.SW24B_pb.TabStop = false;
            this.SW24B_pb.Click += new System.EventHandler(this.SW24B_pb_Click);
            // 
            // SW23B_pb
            // 
            this.SW23B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW23B_pb.Location = new System.Drawing.Point(480, 297);
            this.SW23B_pb.Name = "SW23B_pb";
            this.SW23B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW23B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW23B_pb.TabIndex = 246;
            this.SW23B_pb.TabStop = false;
            this.SW23B_pb.Click += new System.EventHandler(this.SW23B_pb_Click);
            // 
            // SW22B_pb
            // 
            this.SW22B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW22B_pb.Location = new System.Drawing.Point(480, 241);
            this.SW22B_pb.Name = "SW22B_pb";
            this.SW22B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW22B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW22B_pb.TabIndex = 245;
            this.SW22B_pb.TabStop = false;
            this.SW22B_pb.Click += new System.EventHandler(this.SW22B_pb_Click);
            // 
            // SW21B_pb
            // 
            this.SW21B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW21B_pb.Location = new System.Drawing.Point(480, 185);
            this.SW21B_pb.Name = "SW21B_pb";
            this.SW21B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW21B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW21B_pb.TabIndex = 244;
            this.SW21B_pb.TabStop = false;
            this.SW21B_pb.Click += new System.EventHandler(this.SW21B_pb_Click);
            // 
            // SW20B_pb
            // 
            this.SW20B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW20B_pb.Location = new System.Drawing.Point(480, 129);
            this.SW20B_pb.Name = "SW20B_pb";
            this.SW20B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW20B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW20B_pb.TabIndex = 243;
            this.SW20B_pb.TabStop = false;
            this.SW20B_pb.Click += new System.EventHandler(this.SW20B_pb_Click);
            // 
            // SW19B_pb
            // 
            this.SW19B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW19B_pb.Location = new System.Drawing.Point(480, 73);
            this.SW19B_pb.Name = "SW19B_pb";
            this.SW19B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW19B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW19B_pb.TabIndex = 242;
            this.SW19B_pb.TabStop = false;
            this.SW19B_pb.Click += new System.EventHandler(this.SW19B_pb_Click);
            // 
            // SW18B_pb
            // 
            this.SW18B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW18B_pb.Location = new System.Drawing.Point(417, 353);
            this.SW18B_pb.Name = "SW18B_pb";
            this.SW18B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW18B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW18B_pb.TabIndex = 241;
            this.SW18B_pb.TabStop = false;
            this.SW18B_pb.Click += new System.EventHandler(this.SW18B_pb_Click);
            // 
            // SW17B_pb
            // 
            this.SW17B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW17B_pb.Location = new System.Drawing.Point(417, 297);
            this.SW17B_pb.Name = "SW17B_pb";
            this.SW17B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW17B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW17B_pb.TabIndex = 240;
            this.SW17B_pb.TabStop = false;
            this.SW17B_pb.Click += new System.EventHandler(this.SW17B_pb_Click);
            // 
            // SW16B_pb
            // 
            this.SW16B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW16B_pb.Location = new System.Drawing.Point(417, 241);
            this.SW16B_pb.Name = "SW16B_pb";
            this.SW16B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW16B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW16B_pb.TabIndex = 239;
            this.SW16B_pb.TabStop = false;
            this.SW16B_pb.Click += new System.EventHandler(this.SW16B_pb_Click);
            // 
            // SW15B_pb
            // 
            this.SW15B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW15B_pb.Location = new System.Drawing.Point(417, 185);
            this.SW15B_pb.Name = "SW15B_pb";
            this.SW15B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW15B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW15B_pb.TabIndex = 238;
            this.SW15B_pb.TabStop = false;
            this.SW15B_pb.Click += new System.EventHandler(this.SW15B_pb_Click);
            // 
            // SW14B_pb
            // 
            this.SW14B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW14B_pb.Location = new System.Drawing.Point(417, 129);
            this.SW14B_pb.Name = "SW14B_pb";
            this.SW14B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW14B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW14B_pb.TabIndex = 237;
            this.SW14B_pb.TabStop = false;
            this.SW14B_pb.Click += new System.EventHandler(this.SW14B_pb_Click);
            // 
            // SW13B_pb
            // 
            this.SW13B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW13B_pb.Location = new System.Drawing.Point(417, 73);
            this.SW13B_pb.Name = "SW13B_pb";
            this.SW13B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW13B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW13B_pb.TabIndex = 236;
            this.SW13B_pb.TabStop = false;
            this.SW13B_pb.Click += new System.EventHandler(this.SW13B_pb_Click);
            // 
            // SW12B_pb
            // 
            this.SW12B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW12B_pb.Location = new System.Drawing.Point(354, 353);
            this.SW12B_pb.Name = "SW12B_pb";
            this.SW12B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW12B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW12B_pb.TabIndex = 235;
            this.SW12B_pb.TabStop = false;
            this.SW12B_pb.Click += new System.EventHandler(this.SW12B_pb_Click);
            // 
            // SW11B_pb
            // 
            this.SW11B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW11B_pb.Location = new System.Drawing.Point(354, 297);
            this.SW11B_pb.Name = "SW11B_pb";
            this.SW11B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW11B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW11B_pb.TabIndex = 234;
            this.SW11B_pb.TabStop = false;
            this.SW11B_pb.Click += new System.EventHandler(this.SW11B_pb_Click);
            // 
            // SW10B_pb
            // 
            this.SW10B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW10B_pb.Location = new System.Drawing.Point(354, 241);
            this.SW10B_pb.Name = "SW10B_pb";
            this.SW10B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW10B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW10B_pb.TabIndex = 233;
            this.SW10B_pb.TabStop = false;
            this.SW10B_pb.Click += new System.EventHandler(this.SW10B_pb_Click);
            // 
            // SW09B_pb
            // 
            this.SW09B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW09B_pb.Location = new System.Drawing.Point(354, 185);
            this.SW09B_pb.Name = "SW09B_pb";
            this.SW09B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW09B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW09B_pb.TabIndex = 232;
            this.SW09B_pb.TabStop = false;
            this.SW09B_pb.Click += new System.EventHandler(this.SW09B_pb_Click);
            // 
            // SW08B_pb
            // 
            this.SW08B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW08B_pb.Location = new System.Drawing.Point(354, 129);
            this.SW08B_pb.Name = "SW08B_pb";
            this.SW08B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW08B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW08B_pb.TabIndex = 231;
            this.SW08B_pb.TabStop = false;
            this.SW08B_pb.Click += new System.EventHandler(this.SW08B_pb_Click);
            // 
            // SW07B_pb
            // 
            this.SW07B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW07B_pb.Location = new System.Drawing.Point(354, 73);
            this.SW07B_pb.Name = "SW07B_pb";
            this.SW07B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW07B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW07B_pb.TabIndex = 230;
            this.SW07B_pb.TabStop = false;
            this.SW07B_pb.Click += new System.EventHandler(this.SW07B_pb_Click);
            // 
            // SW06B_pb
            // 
            this.SW06B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW06B_pb.Location = new System.Drawing.Point(291, 353);
            this.SW06B_pb.Name = "SW06B_pb";
            this.SW06B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW06B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW06B_pb.TabIndex = 229;
            this.SW06B_pb.TabStop = false;
            this.SW06B_pb.Click += new System.EventHandler(this.SW06B_pb_Click);
            // 
            // SW05B_pb
            // 
            this.SW05B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW05B_pb.Location = new System.Drawing.Point(291, 297);
            this.SW05B_pb.Name = "SW05B_pb";
            this.SW05B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW05B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW05B_pb.TabIndex = 228;
            this.SW05B_pb.TabStop = false;
            this.SW05B_pb.Click += new System.EventHandler(this.SW05B_pb_Click);
            // 
            // SW04B_pb
            // 
            this.SW04B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW04B_pb.Location = new System.Drawing.Point(291, 241);
            this.SW04B_pb.Name = "SW04B_pb";
            this.SW04B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW04B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW04B_pb.TabIndex = 227;
            this.SW04B_pb.TabStop = false;
            this.SW04B_pb.Click += new System.EventHandler(this.SW04B_pb_Click);
            // 
            // SW03B_pb
            // 
            this.SW03B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW03B_pb.Location = new System.Drawing.Point(291, 185);
            this.SW03B_pb.Name = "SW03B_pb";
            this.SW03B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW03B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW03B_pb.TabIndex = 226;
            this.SW03B_pb.TabStop = false;
            this.SW03B_pb.Click += new System.EventHandler(this.SW03B_pb_Click);
            // 
            // SW02B_pb
            // 
            this.SW02B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW02B_pb.Location = new System.Drawing.Point(291, 129);
            this.SW02B_pb.Name = "SW02B_pb";
            this.SW02B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW02B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW02B_pb.TabIndex = 225;
            this.SW02B_pb.TabStop = false;
            this.SW02B_pb.Click += new System.EventHandler(this.SW02B_pb_Click);
            // 
            // SW01B_pb
            // 
            this.SW01B_pb.BackColor = System.Drawing.Color.Transparent;
            this.SW01B_pb.Location = new System.Drawing.Point(291, 73);
            this.SW01B_pb.Name = "SW01B_pb";
            this.SW01B_pb.Size = new System.Drawing.Size(34, 20);
            this.SW01B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.SW01B_pb.TabIndex = 224;
            this.SW01B_pb.TabStop = false;
            this.SW01B_pb.Click += new System.EventHandler(this.SW01B_pb_Click);
            // 
            // ButtonPressIcon36
            // 
            this.ButtonPressIcon36.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon36.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon36.Image")));
            this.ButtonPressIcon36.Location = new System.Drawing.Point(608, 339);
            this.ButtonPressIcon36.Name = "ButtonPressIcon36";
            this.ButtonPressIcon36.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon36.TabIndex = 187;
            this.ButtonPressIcon36.TabStop = false;
            this.ButtonPressIcon36.Visible = false;
            // 
            // ButtonPressIcon35
            // 
            this.ButtonPressIcon35.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon35.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon35.Image")));
            this.ButtonPressIcon35.Location = new System.Drawing.Point(608, 283);
            this.ButtonPressIcon35.Name = "ButtonPressIcon35";
            this.ButtonPressIcon35.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon35.TabIndex = 186;
            this.ButtonPressIcon35.TabStop = false;
            this.ButtonPressIcon35.Visible = false;
            // 
            // ButtonPressIcon34
            // 
            this.ButtonPressIcon34.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon34.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon34.Image")));
            this.ButtonPressIcon34.Location = new System.Drawing.Point(608, 227);
            this.ButtonPressIcon34.Name = "ButtonPressIcon34";
            this.ButtonPressIcon34.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon34.TabIndex = 185;
            this.ButtonPressIcon34.TabStop = false;
            this.ButtonPressIcon34.Visible = false;
            // 
            // ButtonPressIcon33
            // 
            this.ButtonPressIcon33.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon33.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon33.Image")));
            this.ButtonPressIcon33.Location = new System.Drawing.Point(608, 171);
            this.ButtonPressIcon33.Name = "ButtonPressIcon33";
            this.ButtonPressIcon33.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon33.TabIndex = 184;
            this.ButtonPressIcon33.TabStop = false;
            this.ButtonPressIcon33.Visible = false;
            // 
            // ButtonPressIcon32
            // 
            this.ButtonPressIcon32.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon32.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon32.Image")));
            this.ButtonPressIcon32.Location = new System.Drawing.Point(608, 115);
            this.ButtonPressIcon32.Name = "ButtonPressIcon32";
            this.ButtonPressIcon32.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon32.TabIndex = 183;
            this.ButtonPressIcon32.TabStop = false;
            this.ButtonPressIcon32.Visible = false;
            // 
            // ButtonPressIcon31
            // 
            this.ButtonPressIcon31.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon31.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon31.Image")));
            this.ButtonPressIcon31.Location = new System.Drawing.Point(608, 59);
            this.ButtonPressIcon31.Name = "ButtonPressIcon31";
            this.ButtonPressIcon31.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon31.TabIndex = 182;
            this.ButtonPressIcon31.TabStop = false;
            this.ButtonPressIcon31.Visible = false;
            // 
            // ButtonPressIcon30
            // 
            this.ButtonPressIcon30.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon30.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon30.Image")));
            this.ButtonPressIcon30.Location = new System.Drawing.Point(545, 339);
            this.ButtonPressIcon30.Name = "ButtonPressIcon30";
            this.ButtonPressIcon30.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon30.TabIndex = 181;
            this.ButtonPressIcon30.TabStop = false;
            this.ButtonPressIcon30.Visible = false;
            // 
            // ButtonPressIcon29
            // 
            this.ButtonPressIcon29.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon29.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon29.Image")));
            this.ButtonPressIcon29.Location = new System.Drawing.Point(545, 283);
            this.ButtonPressIcon29.Name = "ButtonPressIcon29";
            this.ButtonPressIcon29.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon29.TabIndex = 180;
            this.ButtonPressIcon29.TabStop = false;
            this.ButtonPressIcon29.Visible = false;
            // 
            // ButtonPressIcon28
            // 
            this.ButtonPressIcon28.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon28.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon28.Image")));
            this.ButtonPressIcon28.Location = new System.Drawing.Point(545, 227);
            this.ButtonPressIcon28.Name = "ButtonPressIcon28";
            this.ButtonPressIcon28.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon28.TabIndex = 179;
            this.ButtonPressIcon28.TabStop = false;
            this.ButtonPressIcon28.Visible = false;
            // 
            // ButtonPressIcon27
            // 
            this.ButtonPressIcon27.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon27.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon27.Image")));
            this.ButtonPressIcon27.Location = new System.Drawing.Point(545, 171);
            this.ButtonPressIcon27.Name = "ButtonPressIcon27";
            this.ButtonPressIcon27.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon27.TabIndex = 178;
            this.ButtonPressIcon27.TabStop = false;
            this.ButtonPressIcon27.Visible = false;
            // 
            // ButtonPressIcon26
            // 
            this.ButtonPressIcon26.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon26.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon26.Image")));
            this.ButtonPressIcon26.Location = new System.Drawing.Point(545, 115);
            this.ButtonPressIcon26.Name = "ButtonPressIcon26";
            this.ButtonPressIcon26.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon26.TabIndex = 177;
            this.ButtonPressIcon26.TabStop = false;
            this.ButtonPressIcon26.Visible = false;
            // 
            // ButtonPressIcon25
            // 
            this.ButtonPressIcon25.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon25.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon25.Image")));
            this.ButtonPressIcon25.Location = new System.Drawing.Point(545, 59);
            this.ButtonPressIcon25.Name = "ButtonPressIcon25";
            this.ButtonPressIcon25.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon25.TabIndex = 176;
            this.ButtonPressIcon25.TabStop = false;
            this.ButtonPressIcon25.Visible = false;
            // 
            // ButtonPressIcon24
            // 
            this.ButtonPressIcon24.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon24.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon24.Image")));
            this.ButtonPressIcon24.Location = new System.Drawing.Point(482, 339);
            this.ButtonPressIcon24.Name = "ButtonPressIcon24";
            this.ButtonPressIcon24.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon24.TabIndex = 175;
            this.ButtonPressIcon24.TabStop = false;
            this.ButtonPressIcon24.Visible = false;
            // 
            // ButtonPressIcon23
            // 
            this.ButtonPressIcon23.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon23.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon23.Image")));
            this.ButtonPressIcon23.Location = new System.Drawing.Point(482, 283);
            this.ButtonPressIcon23.Name = "ButtonPressIcon23";
            this.ButtonPressIcon23.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon23.TabIndex = 174;
            this.ButtonPressIcon23.TabStop = false;
            this.ButtonPressIcon23.Visible = false;
            // 
            // ButtonPressIcon22
            // 
            this.ButtonPressIcon22.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon22.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon22.Image")));
            this.ButtonPressIcon22.Location = new System.Drawing.Point(482, 227);
            this.ButtonPressIcon22.Name = "ButtonPressIcon22";
            this.ButtonPressIcon22.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon22.TabIndex = 173;
            this.ButtonPressIcon22.TabStop = false;
            this.ButtonPressIcon22.Visible = false;
            // 
            // ButtonPressIcon21
            // 
            this.ButtonPressIcon21.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon21.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon21.Image")));
            this.ButtonPressIcon21.Location = new System.Drawing.Point(482, 171);
            this.ButtonPressIcon21.Name = "ButtonPressIcon21";
            this.ButtonPressIcon21.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon21.TabIndex = 172;
            this.ButtonPressIcon21.TabStop = false;
            this.ButtonPressIcon21.Visible = false;
            // 
            // ButtonPressIcon20
            // 
            this.ButtonPressIcon20.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon20.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon20.Image")));
            this.ButtonPressIcon20.Location = new System.Drawing.Point(482, 115);
            this.ButtonPressIcon20.Name = "ButtonPressIcon20";
            this.ButtonPressIcon20.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon20.TabIndex = 171;
            this.ButtonPressIcon20.TabStop = false;
            this.ButtonPressIcon20.Visible = false;
            // 
            // ButtonPressIcon19
            // 
            this.ButtonPressIcon19.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon19.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon19.Image")));
            this.ButtonPressIcon19.Location = new System.Drawing.Point(482, 59);
            this.ButtonPressIcon19.Name = "ButtonPressIcon19";
            this.ButtonPressIcon19.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon19.TabIndex = 170;
            this.ButtonPressIcon19.TabStop = false;
            this.ButtonPressIcon19.Visible = false;
            // 
            // ButtonPressIcon18
            // 
            this.ButtonPressIcon18.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon18.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon18.Image")));
            this.ButtonPressIcon18.Location = new System.Drawing.Point(419, 339);
            this.ButtonPressIcon18.Name = "ButtonPressIcon18";
            this.ButtonPressIcon18.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon18.TabIndex = 169;
            this.ButtonPressIcon18.TabStop = false;
            this.ButtonPressIcon18.Visible = false;
            // 
            // ButtonPressIcon17
            // 
            this.ButtonPressIcon17.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon17.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon17.Image")));
            this.ButtonPressIcon17.Location = new System.Drawing.Point(419, 283);
            this.ButtonPressIcon17.Name = "ButtonPressIcon17";
            this.ButtonPressIcon17.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon17.TabIndex = 168;
            this.ButtonPressIcon17.TabStop = false;
            this.ButtonPressIcon17.Visible = false;
            // 
            // ButtonPressIcon16
            // 
            this.ButtonPressIcon16.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon16.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon16.Image")));
            this.ButtonPressIcon16.Location = new System.Drawing.Point(419, 227);
            this.ButtonPressIcon16.Name = "ButtonPressIcon16";
            this.ButtonPressIcon16.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon16.TabIndex = 167;
            this.ButtonPressIcon16.TabStop = false;
            this.ButtonPressIcon16.Visible = false;
            // 
            // ButtonPressIcon15
            // 
            this.ButtonPressIcon15.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon15.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon15.Image")));
            this.ButtonPressIcon15.Location = new System.Drawing.Point(419, 171);
            this.ButtonPressIcon15.Name = "ButtonPressIcon15";
            this.ButtonPressIcon15.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon15.TabIndex = 166;
            this.ButtonPressIcon15.TabStop = false;
            this.ButtonPressIcon15.Visible = false;
            // 
            // ButtonPressIcon14
            // 
            this.ButtonPressIcon14.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon14.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon14.Image")));
            this.ButtonPressIcon14.Location = new System.Drawing.Point(419, 115);
            this.ButtonPressIcon14.Name = "ButtonPressIcon14";
            this.ButtonPressIcon14.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon14.TabIndex = 165;
            this.ButtonPressIcon14.TabStop = false;
            this.ButtonPressIcon14.Visible = false;
            // 
            // ButtonPressIcon13
            // 
            this.ButtonPressIcon13.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon13.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon13.Image")));
            this.ButtonPressIcon13.Location = new System.Drawing.Point(419, 59);
            this.ButtonPressIcon13.Name = "ButtonPressIcon13";
            this.ButtonPressIcon13.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon13.TabIndex = 164;
            this.ButtonPressIcon13.TabStop = false;
            this.ButtonPressIcon13.Visible = false;
            // 
            // ButtonPressIcon12
            // 
            this.ButtonPressIcon12.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon12.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon12.Image")));
            this.ButtonPressIcon12.Location = new System.Drawing.Point(356, 339);
            this.ButtonPressIcon12.Name = "ButtonPressIcon12";
            this.ButtonPressIcon12.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon12.TabIndex = 152;
            this.ButtonPressIcon12.TabStop = false;
            this.ButtonPressIcon12.Visible = false;
            // 
            // ButtonPressIcon11
            // 
            this.ButtonPressIcon11.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon11.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon11.Image")));
            this.ButtonPressIcon11.Location = new System.Drawing.Point(356, 283);
            this.ButtonPressIcon11.Name = "ButtonPressIcon11";
            this.ButtonPressIcon11.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon11.TabIndex = 151;
            this.ButtonPressIcon11.TabStop = false;
            this.ButtonPressIcon11.Visible = false;
            // 
            // ButtonPressIcon10
            // 
            this.ButtonPressIcon10.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon10.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon10.Image")));
            this.ButtonPressIcon10.Location = new System.Drawing.Point(356, 227);
            this.ButtonPressIcon10.Name = "ButtonPressIcon10";
            this.ButtonPressIcon10.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon10.TabIndex = 150;
            this.ButtonPressIcon10.TabStop = false;
            this.ButtonPressIcon10.Visible = false;
            // 
            // ButtonPressIcon9
            // 
            this.ButtonPressIcon9.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon9.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon9.Image")));
            this.ButtonPressIcon9.Location = new System.Drawing.Point(356, 171);
            this.ButtonPressIcon9.Name = "ButtonPressIcon9";
            this.ButtonPressIcon9.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon9.TabIndex = 149;
            this.ButtonPressIcon9.TabStop = false;
            this.ButtonPressIcon9.Visible = false;
            // 
            // ButtonPressIcon8
            // 
            this.ButtonPressIcon8.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon8.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon8.Image")));
            this.ButtonPressIcon8.Location = new System.Drawing.Point(356, 115);
            this.ButtonPressIcon8.Name = "ButtonPressIcon8";
            this.ButtonPressIcon8.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon8.TabIndex = 148;
            this.ButtonPressIcon8.TabStop = false;
            this.ButtonPressIcon8.Visible = false;
            // 
            // Arrow_Mouse3_pb
            // 
            this.Arrow_Mouse3_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Mouse3_pb.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.Arrow_Mouse3_pb.Location = new System.Drawing.Point(109, 224);
            this.Arrow_Mouse3_pb.Name = "Arrow_Mouse3_pb";
            this.Arrow_Mouse3_pb.Size = new System.Drawing.Size(9, 12);
            this.Arrow_Mouse3_pb.TabIndex = 137;
            this.Arrow_Mouse3_pb.TabStop = false;
            this.Arrow_Mouse3_pb.Visible = false;
            // 
            // Speed_Mouse5_pb
            // 
            this.Speed_Mouse5_pb.BackColor = System.Drawing.Color.White;
            this.Speed_Mouse5_pb.Image = global::Revive_Micro_CT.Properties.Resources.Mouse_sokudo;
            this.Speed_Mouse5_pb.Location = new System.Drawing.Point(58, 277);
            this.Speed_Mouse5_pb.Name = "Speed_Mouse5_pb";
            this.Speed_Mouse5_pb.Size = new System.Drawing.Size(111, 24);
            this.Speed_Mouse5_pb.TabIndex = 136;
            this.Speed_Mouse5_pb.TabStop = false;
            this.Speed_Mouse5_pb.Visible = false;
            // 
            // Arrow_Mouse2_pb
            // 
            this.Arrow_Mouse2_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Mouse2_pb.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.Arrow_Mouse2_pb.Location = new System.Drawing.Point(109, 306);
            this.Arrow_Mouse2_pb.Name = "Arrow_Mouse2_pb";
            this.Arrow_Mouse2_pb.Size = new System.Drawing.Size(9, 12);
            this.Arrow_Mouse2_pb.TabIndex = 135;
            this.Arrow_Mouse2_pb.TabStop = false;
            this.Arrow_Mouse2_pb.Visible = false;
            // 
            // Speed_Mouse4_pb
            // 
            this.Speed_Mouse4_pb.BackColor = System.Drawing.Color.White;
            this.Speed_Mouse4_pb.Image = global::Revive_Micro_CT.Properties.Resources.Mouse_idou;
            this.Speed_Mouse4_pb.Location = new System.Drawing.Point(91, 239);
            this.Speed_Mouse4_pb.Name = "Speed_Mouse4_pb";
            this.Speed_Mouse4_pb.Size = new System.Drawing.Size(45, 13);
            this.Speed_Mouse4_pb.TabIndex = 134;
            this.Speed_Mouse4_pb.TabStop = false;
            this.Speed_Mouse4_pb.Visible = false;
            // 
            // Arrow_Mouse1_pb
            // 
            this.Arrow_Mouse1_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Mouse1_pb.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.Arrow_Mouse1_pb.Location = new System.Drawing.Point(109, 342);
            this.Arrow_Mouse1_pb.Name = "Arrow_Mouse1_pb";
            this.Arrow_Mouse1_pb.Size = new System.Drawing.Size(9, 12);
            this.Arrow_Mouse1_pb.TabIndex = 133;
            this.Arrow_Mouse1_pb.TabStop = false;
            this.Arrow_Mouse1_pb.Visible = false;
            // 
            // Pin02B_pb
            // 
            this.Pin02B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin02B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_02;
            this.Pin02B_pb.Location = new System.Drawing.Point(358, 32);
            this.Pin02B_pb.Name = "Pin02B_pb";
            this.Pin02B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin02B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin02B_pb.TabIndex = 126;
            this.Pin02B_pb.TabStop = false;
            this.Pin02B_pb.Visible = false;
            // 
            // Pin03B_pb
            // 
            this.Pin03B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin03B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_03;
            this.Pin03B_pb.Location = new System.Drawing.Point(421, 32);
            this.Pin03B_pb.Name = "Pin03B_pb";
            this.Pin03B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin03B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin03B_pb.TabIndex = 125;
            this.Pin03B_pb.TabStop = false;
            this.Pin03B_pb.Visible = false;
            // 
            // Pin04B_pb
            // 
            this.Pin04B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin04B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_04;
            this.Pin04B_pb.Location = new System.Drawing.Point(484, 32);
            this.Pin04B_pb.Name = "Pin04B_pb";
            this.Pin04B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin04B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin04B_pb.TabIndex = 124;
            this.Pin04B_pb.TabStop = false;
            this.Pin04B_pb.Visible = false;
            // 
            // Pin01B_pb
            // 
            this.Pin01B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin01B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_01;
            this.Pin01B_pb.Location = new System.Drawing.Point(295, 32);
            this.Pin01B_pb.Name = "Pin01B_pb";
            this.Pin01B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin01B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin01B_pb.TabIndex = 123;
            this.Pin01B_pb.TabStop = false;
            this.Pin01B_pb.Visible = false;
            // 
            // Pin05B_pb
            // 
            this.Pin05B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin05B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_05;
            this.Pin05B_pb.Location = new System.Drawing.Point(547, 32);
            this.Pin05B_pb.Name = "Pin05B_pb";
            this.Pin05B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin05B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin05B_pb.TabIndex = 122;
            this.Pin05B_pb.TabStop = false;
            this.Pin05B_pb.Visible = false;
            // 
            // Pin06B_pb
            // 
            this.Pin06B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin06B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_06;
            this.Pin06B_pb.Location = new System.Drawing.Point(610, 32);
            this.Pin06B_pb.Name = "Pin06B_pb";
            this.Pin06B_pb.Size = new System.Drawing.Size(40, 15);
            this.Pin06B_pb.TabIndex = 121;
            this.Pin06B_pb.TabStop = false;
            this.Pin06B_pb.Visible = false;
            // 
            // Pin07B_pb
            // 
            this.Pin07B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin07B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_07;
            this.Pin07B_pb.Location = new System.Drawing.Point(215, 80);
            this.Pin07B_pb.Name = "Pin07B_pb";
            this.Pin07B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin07B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin07B_pb.TabIndex = 119;
            this.Pin07B_pb.TabStop = false;
            this.Pin07B_pb.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = global::Revive_Micro_CT.Properties.Resources.ASSIGN;
            this.pictureBox8.Location = new System.Drawing.Point(70, 405);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(89, 13);
            this.pictureBox8.TabIndex = 116;
            this.pictureBox8.TabStop = false;
            // 
            // Arrow_Com_pb
            // 
            this.Arrow_Com_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Com_pb.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.Arrow_Com_pb.Location = new System.Drawing.Point(109, 375);
            this.Arrow_Com_pb.Name = "Arrow_Com_pb";
            this.Arrow_Com_pb.Size = new System.Drawing.Size(9, 12);
            this.Arrow_Com_pb.TabIndex = 115;
            this.Arrow_Com_pb.TabStop = false;
            this.Arrow_Com_pb.Visible = false;
            // 
            // Arrow_Keyboard_pb
            // 
            this.Arrow_Keyboard_pb.BackColor = System.Drawing.Color.Transparent;
            this.Arrow_Keyboard_pb.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.Arrow_Keyboard_pb.Location = new System.Drawing.Point(109, 294);
            this.Arrow_Keyboard_pb.Name = "Arrow_Keyboard_pb";
            this.Arrow_Keyboard_pb.Size = new System.Drawing.Size(9, 12);
            this.Arrow_Keyboard_pb.TabIndex = 114;
            this.Arrow_Keyboard_pb.TabStop = false;
            this.Arrow_Keyboard_pb.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::Revive_Micro_CT.Properties.Resources.F_wariate;
            this.pictureBox5.Location = new System.Drawing.Point(96, 182);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(34, 13);
            this.pictureBox5.TabIndex = 113;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::Revive_Micro_CT.Properties.Resources.F_arrow;
            this.pictureBox3.Location = new System.Drawing.Point(109, 166);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(9, 12);
            this.pictureBox3.TabIndex = 97;
            this.pictureBox3.TabStop = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.White;
            this.Status_NC_pb.Image = global::Revive_Micro_CT.Properties.Resources.STATUS_DISCON;
            this.Status_NC_pb.Location = new System.Drawing.Point(843, 489);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.White;
            this.Status_C_pb.Image = global::Revive_Micro_CT.Properties.Resources.STATUS_CON;
            this.Status_C_pb.Location = new System.Drawing.Point(843, 489);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // ButtonPressIcon5
            // 
            this.ButtonPressIcon5.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon5.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon5.Image")));
            this.ButtonPressIcon5.Location = new System.Drawing.Point(293, 283);
            this.ButtonPressIcon5.Name = "ButtonPressIcon5";
            this.ButtonPressIcon5.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon5.TabIndex = 92;
            this.ButtonPressIcon5.TabStop = false;
            this.ButtonPressIcon5.Visible = false;
            // 
            // ButtonPressIcon6
            // 
            this.ButtonPressIcon6.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon6.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon6.Image")));
            this.ButtonPressIcon6.Location = new System.Drawing.Point(293, 339);
            this.ButtonPressIcon6.Name = "ButtonPressIcon6";
            this.ButtonPressIcon6.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon6.TabIndex = 91;
            this.ButtonPressIcon6.TabStop = false;
            this.ButtonPressIcon6.Visible = false;
            // 
            // ButtonPressIcon7
            // 
            this.ButtonPressIcon7.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon7.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon7.Image")));
            this.ButtonPressIcon7.Location = new System.Drawing.Point(356, 59);
            this.ButtonPressIcon7.Name = "ButtonPressIcon7";
            this.ButtonPressIcon7.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon7.TabIndex = 90;
            this.ButtonPressIcon7.TabStop = false;
            this.ButtonPressIcon7.Visible = false;
            // 
            // Changevalue_btn
            // 
            this.Changevalue_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.Changevalue_btn.BackgroundImage = global::Revive_Micro_CT.Properties.Resources.DONE;
            this.Changevalue_btn.Enabled = false;
            this.Changevalue_btn.Location = new System.Drawing.Point(53, 420);
            this.Changevalue_btn.Name = "Changevalue_btn";
            this.Changevalue_btn.Size = new System.Drawing.Size(121, 29);
            this.Changevalue_btn.TabIndex = 24;
            this.Changevalue_btn.UseVisualStyleBackColor = false;
            this.Changevalue_btn.Click += new System.EventHandler(this.Changevalue_btn_Click);
            this.Changevalue_btn.MouseEnter += new System.EventHandler(this.Changevalue_btn_MouseEnter);
            this.Changevalue_btn.MouseLeave += new System.EventHandler(this.Changevalue_btn_MouseLeave);
            // 
            // ButtonPressIcon4
            // 
            this.ButtonPressIcon4.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon4.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon4.Image")));
            this.ButtonPressIcon4.Location = new System.Drawing.Point(293, 227);
            this.ButtonPressIcon4.Name = "ButtonPressIcon4";
            this.ButtonPressIcon4.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon4.TabIndex = 87;
            this.ButtonPressIcon4.TabStop = false;
            this.ButtonPressIcon4.Visible = false;
            // 
            // ButtonPressIcon3
            // 
            this.ButtonPressIcon3.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon3.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon3.Image")));
            this.ButtonPressIcon3.Location = new System.Drawing.Point(293, 171);
            this.ButtonPressIcon3.Name = "ButtonPressIcon3";
            this.ButtonPressIcon3.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon3.TabIndex = 86;
            this.ButtonPressIcon3.TabStop = false;
            this.ButtonPressIcon3.Visible = false;
            // 
            // ButtonPressIcon2
            // 
            this.ButtonPressIcon2.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon2.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon2.Image")));
            this.ButtonPressIcon2.InitialImage = null;
            this.ButtonPressIcon2.Location = new System.Drawing.Point(293, 115);
            this.ButtonPressIcon2.Name = "ButtonPressIcon2";
            this.ButtonPressIcon2.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon2.TabIndex = 85;
            this.ButtonPressIcon2.TabStop = false;
            this.ButtonPressIcon2.Visible = false;
            // 
            // ButtonPressIcon1
            // 
            this.ButtonPressIcon1.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPressIcon1.Image = ((System.Drawing.Image)(resources.GetObject("ButtonPressIcon1.Image")));
            this.ButtonPressIcon1.Location = new System.Drawing.Point(293, 59);
            this.ButtonPressIcon1.Name = "ButtonPressIcon1";
            this.ButtonPressIcon1.Size = new System.Drawing.Size(39, 12);
            this.ButtonPressIcon1.TabIndex = 84;
            this.ButtonPressIcon1.TabStop = false;
            this.ButtonPressIcon1.Visible = false;
            // 
            // Pin08B_pb
            // 
            this.Pin08B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin08B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_08;
            this.Pin08B_pb.Location = new System.Drawing.Point(215, 136);
            this.Pin08B_pb.Name = "Pin08B_pb";
            this.Pin08B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin08B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin08B_pb.TabIndex = 143;
            this.Pin08B_pb.TabStop = false;
            this.Pin08B_pb.Visible = false;
            // 
            // Pin09B_pb
            // 
            this.Pin09B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin09B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_09;
            this.Pin09B_pb.Location = new System.Drawing.Point(215, 192);
            this.Pin09B_pb.Name = "Pin09B_pb";
            this.Pin09B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin09B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin09B_pb.TabIndex = 144;
            this.Pin09B_pb.TabStop = false;
            this.Pin09B_pb.Visible = false;
            // 
            // Pin10B_pb
            // 
            this.Pin10B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin10B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_10;
            this.Pin10B_pb.Location = new System.Drawing.Point(215, 248);
            this.Pin10B_pb.Name = "Pin10B_pb";
            this.Pin10B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin10B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin10B_pb.TabIndex = 145;
            this.Pin10B_pb.TabStop = false;
            this.Pin10B_pb.Visible = false;
            // 
            // Pin11B_pb
            // 
            this.Pin11B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin11B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_11;
            this.Pin11B_pb.Location = new System.Drawing.Point(215, 304);
            this.Pin11B_pb.Name = "Pin11B_pb";
            this.Pin11B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin11B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin11B_pb.TabIndex = 146;
            this.Pin11B_pb.TabStop = false;
            this.Pin11B_pb.Visible = false;
            // 
            // Pin12B_pb
            // 
            this.Pin12B_pb.BackColor = System.Drawing.SystemColors.Control;
            this.Pin12B_pb.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_PIN_12;
            this.Pin12B_pb.Location = new System.Drawing.Point(215, 360);
            this.Pin12B_pb.Name = "Pin12B_pb";
            this.Pin12B_pb.Size = new System.Drawing.Size(41, 14);
            this.Pin12B_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Pin12B_pb.TabIndex = 147;
            this.Pin12B_pb.TabStop = false;
            this.Pin12B_pb.Visible = false;
            // 
            // BackGround
            // 
            this.BackGround.Image = global::Revive_Micro_CT.Properties.Resources.MATRIX_BG;
            this.BackGround.Location = new System.Drawing.Point(0, 0);
            this.BackGround.Name = "BackGround";
            this.BackGround.Size = new System.Drawing.Size(878, 500);
            this.BackGround.TabIndex = 296;
            this.BackGround.TabStop = false;
            // 
            // lbl_FWVersion
            // 
            this.lbl_FWVersion.AutoSize = true;
            this.lbl_FWVersion.BackColor = System.Drawing.Color.Transparent;
            this.lbl_FWVersion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.lbl_FWVersion.Location = new System.Drawing.Point(756, 475);
            this.lbl_FWVersion.Name = "lbl_FWVersion";
            this.lbl_FWVersion.Size = new System.Drawing.Size(88, 12);
            this.lbl_FWVersion.TabIndex = 298;
            this.lbl_FWVersion.Text = "FW Version: ***";
            // 
            // AllButtonSetting_grpbox
            // 
            this.AllButtonSetting_grpbox.BackColor = System.Drawing.SystemColors.Control;
            this.AllButtonSetting_grpbox.Controls.Add(this.check_count_numUpDown);
            this.AllButtonSetting_grpbox.Controls.Add(this.smpl_interval_numUpDown);
            this.AllButtonSetting_grpbox.Controls.Add(this.lbl_delay_calc_result);
            this.AllButtonSetting_grpbox.Controls.Add(this.lbl_delay_calc);
            this.AllButtonSetting_grpbox.Controls.Add(this.check_count_lbl);
            this.AllButtonSetting_grpbox.Controls.Add(this.check_count_desc_lbl);
            this.AllButtonSetting_grpbox.Controls.Add(this.smpl_interval_lbl);
            this.AllButtonSetting_grpbox.Controls.Add(this.smpl_interval_desc_lbl);
            this.AllButtonSetting_grpbox.Enabled = false;
            this.AllButtonSetting_grpbox.Location = new System.Drawing.Point(303, 383);
            this.AllButtonSetting_grpbox.Name = "AllButtonSetting_grpbox";
            this.AllButtonSetting_grpbox.Size = new System.Drawing.Size(166, 87);
            this.AllButtonSetting_grpbox.TabIndex = 299;
            this.AllButtonSetting_grpbox.TabStop = false;
            this.AllButtonSetting_grpbox.Text = "�`���^�����O�h�~�ݒ�";
            // 
            // check_count_numUpDown
            // 
            this.check_count_numUpDown.Location = new System.Drawing.Point(95, 38);
            this.check_count_numUpDown.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.check_count_numUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.check_count_numUpDown.Name = "check_count_numUpDown";
            this.check_count_numUpDown.Size = new System.Drawing.Size(40, 19);
            this.check_count_numUpDown.TabIndex = 7;
            this.check_count_numUpDown.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.check_count_numUpDown.ValueChanged += new System.EventHandler(this.check_count_numUpDown_ValueChanged);
            // 
            // smpl_interval_numUpDown
            // 
            this.smpl_interval_numUpDown.Location = new System.Drawing.Point(95, 15);
            this.smpl_interval_numUpDown.Maximum = new decimal(new int[] {
            174,
            0,
            0,
            0});
            this.smpl_interval_numUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.smpl_interval_numUpDown.Name = "smpl_interval_numUpDown";
            this.smpl_interval_numUpDown.Size = new System.Drawing.Size(40, 19);
            this.smpl_interval_numUpDown.TabIndex = 6;
            this.smpl_interval_numUpDown.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.smpl_interval_numUpDown.ValueChanged += new System.EventHandler(this.smpl_interval_numUpDown_ValueChanged);
            // 
            // lbl_delay_calc_result
            // 
            this.lbl_delay_calc_result.AutoSize = true;
            this.lbl_delay_calc_result.Location = new System.Drawing.Point(93, 63);
            this.lbl_delay_calc_result.Name = "lbl_delay_calc_result";
            this.lbl_delay_calc_result.Size = new System.Drawing.Size(26, 12);
            this.lbl_delay_calc_result.TabIndex = 5;
            this.lbl_delay_calc_result.Text = "6ms";
            // 
            // lbl_delay_calc
            // 
            this.lbl_delay_calc.AutoSize = true;
            this.lbl_delay_calc.Location = new System.Drawing.Point(14, 63);
            this.lbl_delay_calc.Name = "lbl_delay_calc";
            this.lbl_delay_calc.Size = new System.Drawing.Size(77, 12);
            this.lbl_delay_calc.TabIndex = 4;
            this.lbl_delay_calc.Text = "���ϒx���b��";
            // 
            // check_count_lbl
            // 
            this.check_count_lbl.AutoSize = true;
            this.check_count_lbl.Location = new System.Drawing.Point(136, 41);
            this.check_count_lbl.Name = "check_count_lbl";
            this.check_count_lbl.Size = new System.Drawing.Size(17, 12);
            this.check_count_lbl.TabIndex = 3;
            this.check_count_lbl.Text = "��";
            // 
            // check_count_desc_lbl
            // 
            this.check_count_desc_lbl.AutoSize = true;
            this.check_count_desc_lbl.Location = new System.Drawing.Point(15, 41);
            this.check_count_desc_lbl.Name = "check_count_desc_lbl";
            this.check_count_desc_lbl.Size = new System.Drawing.Size(77, 12);
            this.check_count_desc_lbl.TabIndex = 2;
            this.check_count_desc_lbl.Text = "��v���o��";
            // 
            // smpl_interval_lbl
            // 
            this.smpl_interval_lbl.AutoSize = true;
            this.smpl_interval_lbl.Location = new System.Drawing.Point(135, 18);
            this.smpl_interval_lbl.Name = "smpl_interval_lbl";
            this.smpl_interval_lbl.Size = new System.Drawing.Size(20, 12);
            this.smpl_interval_lbl.TabIndex = 1;
            this.smpl_interval_lbl.Text = "ms";
            // 
            // smpl_interval_desc_lbl
            // 
            this.smpl_interval_desc_lbl.AutoSize = true;
            this.smpl_interval_desc_lbl.Location = new System.Drawing.Point(9, 19);
            this.smpl_interval_desc_lbl.Name = "smpl_interval_desc_lbl";
            this.smpl_interval_desc_lbl.Size = new System.Drawing.Size(82, 12);
            this.smpl_interval_desc_lbl.TabIndex = 0;
            this.smpl_interval_desc_lbl.Text = "�T���v�����O����";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(878, 500);
            this.Controls.Add(this.AllButtonSetting_grpbox);
            this.Controls.Add(this.lbl_FWVersion);
            this.Controls.Add(this.update_btn);
            this.Controls.Add(this.SW36B_pb);
            this.Controls.Add(this.SW35B_pb);
            this.Controls.Add(this.SW34B_pb);
            this.Controls.Add(this.SW33B_pb);
            this.Controls.Add(this.SW32B_pb);
            this.Controls.Add(this.SW31B_pb);
            this.Controls.Add(this.SW30B_pb);
            this.Controls.Add(this.SW29B_pb);
            this.Controls.Add(this.SW28B_pb);
            this.Controls.Add(this.SW27B_pb);
            this.Controls.Add(this.SW26B_pb);
            this.Controls.Add(this.SW25B_pb);
            this.Controls.Add(this.SW24B_pb);
            this.Controls.Add(this.SW23B_pb);
            this.Controls.Add(this.SW22B_pb);
            this.Controls.Add(this.SW21B_pb);
            this.Controls.Add(this.SW20B_pb);
            this.Controls.Add(this.SW19B_pb);
            this.Controls.Add(this.SW18B_pb);
            this.Controls.Add(this.SW17B_pb);
            this.Controls.Add(this.SW16B_pb);
            this.Controls.Add(this.SW15B_pb);
            this.Controls.Add(this.SW14B_pb);
            this.Controls.Add(this.SW13B_pb);
            this.Controls.Add(this.SW12B_pb);
            this.Controls.Add(this.SW11B_pb);
            this.Controls.Add(this.SW10B_pb);
            this.Controls.Add(this.SW09B_pb);
            this.Controls.Add(this.SW08B_pb);
            this.Controls.Add(this.SW07B_pb);
            this.Controls.Add(this.SW06B_pb);
            this.Controls.Add(this.SW05B_pb);
            this.Controls.Add(this.SW04B_pb);
            this.Controls.Add(this.SW03B_pb);
            this.Controls.Add(this.SW02B_pb);
            this.Controls.Add(this.SW01B_pb);
            this.Controls.Add(this.ButtonPressIcon36);
            this.Controls.Add(this.ButtonPressIcon35);
            this.Controls.Add(this.ButtonPressIcon34);
            this.Controls.Add(this.ButtonPressIcon33);
            this.Controls.Add(this.ButtonPressIcon32);
            this.Controls.Add(this.ButtonPressIcon31);
            this.Controls.Add(this.ButtonPressIcon30);
            this.Controls.Add(this.ButtonPressIcon29);
            this.Controls.Add(this.ButtonPressIcon28);
            this.Controls.Add(this.ButtonPressIcon27);
            this.Controls.Add(this.ButtonPressIcon26);
            this.Controls.Add(this.ButtonPressIcon25);
            this.Controls.Add(this.ButtonPressIcon24);
            this.Controls.Add(this.ButtonPressIcon23);
            this.Controls.Add(this.ButtonPressIcon22);
            this.Controls.Add(this.ButtonPressIcon21);
            this.Controls.Add(this.ButtonPressIcon20);
            this.Controls.Add(this.ButtonPressIcon19);
            this.Controls.Add(this.ButtonPressIcon18);
            this.Controls.Add(this.ButtonPressIcon17);
            this.Controls.Add(this.ButtonPressIcon16);
            this.Controls.Add(this.ButtonPressIcon15);
            this.Controls.Add(this.ButtonPressIcon14);
            this.Controls.Add(this.ButtonPressIcon13);
            this.Controls.Add(this.Button_list);
            this.Controls.Add(this.ButtonPressIcon12);
            this.Controls.Add(this.ButtonPressIcon11);
            this.Controls.Add(this.ButtonPressIcon10);
            this.Controls.Add(this.ButtonPressIcon9);
            this.Controls.Add(this.ButtonPressIcon8);
            this.Controls.Add(this.Arrow_Mouse3_pb);
            this.Controls.Add(this.Speed_Mouse5_pb);
            this.Controls.Add(this.Arrow_Mouse2_pb);
            this.Controls.Add(this.Speed_Mouse4_pb);
            this.Controls.Add(this.Arrow_Mouse1_pb);
            this.Controls.Add(this.Pin02B_pb);
            this.Controls.Add(this.Pin03B_pb);
            this.Controls.Add(this.Pin04B_pb);
            this.Controls.Add(this.Pin01B_pb);
            this.Controls.Add(this.Pin05B_pb);
            this.Controls.Add(this.Pin06B_pb);
            this.Controls.Add(this.Pin07B_pb);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.Arrow_Com_pb);
            this.Controls.Add(this.Arrow_Keyboard_pb);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.Status_NC_pb);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.MouseMove_UD);
            this.Controls.Add(this.Button12_cbox);
            this.Controls.Add(this.Button11_cbox);
            this.Controls.Add(this.Button10_cbox);
            this.Controls.Add(this.Button9_cbox);
            this.Controls.Add(this.Button8_cbox);
            this.Controls.Add(this.Button7_cbox);
            this.Controls.Add(this.SetPin_combox);
            this.Controls.Add(this.Button6_cbox);
            this.Controls.Add(this.Button5_cbox);
            this.Controls.Add(this.Button4_cbox);
            this.Controls.Add(this.ButtonPressIcon5);
            this.Controls.Add(this.Button3_cbox);
            this.Controls.Add(this.Button2_cbox);
            this.Controls.Add(this.Button1_cbox);
            this.Controls.Add(this.LeverRight_cbox);
            this.Controls.Add(this.ButtonPressIcon6);
            this.Controls.Add(this.LeverLeft_cbox);
            this.Controls.Add(this.LeverDown_cbox);
            this.Controls.Add(this.LeverUp_cbox);
            this.Controls.Add(this.Win_cbox);
            this.Controls.Add(this.ButtonPressIcon7);
            this.Controls.Add(this.Shift_cbox);
            this.Controls.Add(this.Alt_cbox);
            this.Controls.Add(this.Ctrl_cbox);
            this.Controls.Add(this.KeyboardValue_txtbx);
            this.Controls.Add(this.mousevalue_combx);
            this.Controls.Add(this.devicetype_combox);
            this.Controls.Add(this.Changevalue_btn);
            this.Controls.Add(this.ButtonPressIcon4);
            this.Controls.Add(this.ButtonPressIcon3);
            this.Controls.Add(this.ButtonPressIcon2);
            this.Controls.Add(this.ButtonPressIcon1);
            this.Controls.Add(this.Pin08B_pb);
            this.Controls.Add(this.Pin09B_pb);
            this.Controls.Add(this.Pin10B_pb);
            this.Controls.Add(this.Pin11B_pb);
            this.Controls.Add(this.Pin12B_pb);
            this.Controls.Add(this.BackGround);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(894, 538);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "REVIVE USB MICRO Debounce MATRIX, Configuration Tool ver ";
            ((System.ComponentModel.ISupportInitialize)(this.MouseMove_UD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW36B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW35B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW34B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW33B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW32B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW31B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW30B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW29B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW28B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW27B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW26B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW25B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW24B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW23B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW22B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW21B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW20B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW19B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW18B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW17B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW16B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW15B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW14B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW13B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW12B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW11B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW10B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW09B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW08B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW07B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW06B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW05B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW04B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW03B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW02B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SW01B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse3_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Speed_Mouse5_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse2_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Speed_Mouse4_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Mouse1_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin02B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin03B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin04B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin01B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin05B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin06B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin07B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Com_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Arrow_Keyboard_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ButtonPressIcon1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin08B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin09B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin10B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin11B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pin12B_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BackGround)).EndInit();
            this.AllButtonSetting_grpbox.ResumeLayout(false);
            this.AllButtonSetting_grpbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.check_count_numUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smpl_interval_numUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Changevalue_btn;
        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ComboBox devicetype_combox;
        private System.Windows.Forms.ComboBox mousevalue_combx;
        private System.Windows.Forms.TextBox KeyboardValue_txtbx;
        private System.Windows.Forms.CheckBox Ctrl_cbox;
        private System.Windows.Forms.CheckBox Win_cbox;
        private System.Windows.Forms.CheckBox Shift_cbox;
        private System.Windows.Forms.CheckBox Alt_cbox;
        private System.Windows.Forms.CheckBox LeverDown_cbox;
        private System.Windows.Forms.CheckBox LeverUp_cbox;
        private System.Windows.Forms.CheckBox LeverRight_cbox;
        private System.Windows.Forms.CheckBox LeverLeft_cbox;
        private System.Windows.Forms.CheckBox Button6_cbox;
        private System.Windows.Forms.CheckBox Button5_cbox;
        private System.Windows.Forms.CheckBox Button4_cbox;
        private System.Windows.Forms.CheckBox Button3_cbox;
        private System.Windows.Forms.CheckBox Button2_cbox;
        private System.Windows.Forms.CheckBox Button1_cbox;
        private System.Windows.Forms.ComboBox SetPin_combox;
        private System.Windows.Forms.CheckBox Button12_cbox;
        private System.Windows.Forms.CheckBox Button11_cbox;
        private System.Windows.Forms.CheckBox Button10_cbox;
        private System.Windows.Forms.CheckBox Button9_cbox;
        private System.Windows.Forms.CheckBox Button8_cbox;
        private System.Windows.Forms.CheckBox Button7_cbox;
        private System.Windows.Forms.NumericUpDown MouseMove_UD;
        private System.Windows.Forms.PictureBox ButtonPressIcon1;
        private System.Windows.Forms.PictureBox ButtonPressIcon2;
        private System.Windows.Forms.PictureBox ButtonPressIcon3;
        private System.Windows.Forms.PictureBox ButtonPressIcon4;
        private System.Windows.Forms.PictureBox ButtonPressIcon7;
        private System.Windows.Forms.PictureBox ButtonPressIcon6;
        private System.Windows.Forms.PictureBox ButtonPressIcon5;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox Arrow_Keyboard_pb;
        private System.Windows.Forms.PictureBox Arrow_Com_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.PictureBox Pin07B_pb;
        private System.Windows.Forms.PictureBox Pin06B_pb;
        private System.Windows.Forms.PictureBox Pin05B_pb;
        private System.Windows.Forms.PictureBox Pin01B_pb;
        private System.Windows.Forms.PictureBox Pin04B_pb;
        private System.Windows.Forms.PictureBox Pin03B_pb;
        private System.Windows.Forms.PictureBox Pin02B_pb;
        private System.Windows.Forms.PictureBox Arrow_Mouse1_pb;
        private System.Windows.Forms.PictureBox Speed_Mouse4_pb;
        private System.Windows.Forms.PictureBox Arrow_Mouse2_pb;
        private System.Windows.Forms.PictureBox Speed_Mouse5_pb;
        private System.Windows.Forms.PictureBox Arrow_Mouse3_pb;
        private System.Windows.Forms.PictureBox Pin08B_pb;
        private System.Windows.Forms.PictureBox Pin09B_pb;
        private System.Windows.Forms.PictureBox Pin10B_pb;
        private System.Windows.Forms.PictureBox Pin11B_pb;
        private System.Windows.Forms.PictureBox Pin12B_pb;
        private System.Windows.Forms.PictureBox ButtonPressIcon8;
        private System.Windows.Forms.PictureBox ButtonPressIcon9;
        private System.Windows.Forms.PictureBox ButtonPressIcon10;
        private System.Windows.Forms.PictureBox ButtonPressIcon11;
        private System.Windows.Forms.PictureBox ButtonPressIcon12;
        private System.Windows.Forms.ListView Button_list;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.PictureBox ButtonPressIcon13;
        private System.Windows.Forms.PictureBox ButtonPressIcon14;
        private System.Windows.Forms.PictureBox ButtonPressIcon15;
        private System.Windows.Forms.PictureBox ButtonPressIcon16;
        private System.Windows.Forms.PictureBox ButtonPressIcon17;
        private System.Windows.Forms.PictureBox ButtonPressIcon18;
        private System.Windows.Forms.PictureBox ButtonPressIcon19;
        private System.Windows.Forms.PictureBox ButtonPressIcon20;
        private System.Windows.Forms.PictureBox ButtonPressIcon21;
        private System.Windows.Forms.PictureBox ButtonPressIcon22;
        private System.Windows.Forms.PictureBox ButtonPressIcon23;
        private System.Windows.Forms.PictureBox ButtonPressIcon24;
        private System.Windows.Forms.PictureBox ButtonPressIcon25;
        private System.Windows.Forms.PictureBox ButtonPressIcon26;
        private System.Windows.Forms.PictureBox ButtonPressIcon27;
        private System.Windows.Forms.PictureBox ButtonPressIcon28;
        private System.Windows.Forms.PictureBox ButtonPressIcon29;
        private System.Windows.Forms.PictureBox ButtonPressIcon30;
        private System.Windows.Forms.PictureBox ButtonPressIcon31;
        private System.Windows.Forms.PictureBox ButtonPressIcon32;
        private System.Windows.Forms.PictureBox ButtonPressIcon33;
        private System.Windows.Forms.PictureBox ButtonPressIcon34;
        private System.Windows.Forms.PictureBox ButtonPressIcon35;
        private System.Windows.Forms.PictureBox ButtonPressIcon36;
        private System.Windows.Forms.PictureBox SW01B_pb;
        private System.Windows.Forms.PictureBox SW02B_pb;
        private System.Windows.Forms.PictureBox SW03B_pb;
        private System.Windows.Forms.PictureBox SW04B_pb;
        private System.Windows.Forms.PictureBox SW05B_pb;
        private System.Windows.Forms.PictureBox SW06B_pb;
        private System.Windows.Forms.PictureBox SW07B_pb;
        private System.Windows.Forms.PictureBox SW08B_pb;
        private System.Windows.Forms.PictureBox SW09B_pb;
        private System.Windows.Forms.PictureBox SW10B_pb;
        private System.Windows.Forms.PictureBox SW11B_pb;
        private System.Windows.Forms.PictureBox SW12B_pb;
        private System.Windows.Forms.PictureBox SW13B_pb;
        private System.Windows.Forms.PictureBox SW14B_pb;
        private System.Windows.Forms.PictureBox SW15B_pb;
        private System.Windows.Forms.PictureBox SW16B_pb;
        private System.Windows.Forms.PictureBox SW17B_pb;
        private System.Windows.Forms.PictureBox SW18B_pb;
        private System.Windows.Forms.PictureBox SW19B_pb;
        private System.Windows.Forms.PictureBox SW20B_pb;
        private System.Windows.Forms.PictureBox SW21B_pb;
        private System.Windows.Forms.PictureBox SW22B_pb;
        private System.Windows.Forms.PictureBox SW23B_pb;
        private System.Windows.Forms.PictureBox SW24B_pb;
        private System.Windows.Forms.PictureBox SW25B_pb;
        private System.Windows.Forms.PictureBox SW26B_pb;
        private System.Windows.Forms.PictureBox SW27B_pb;
        private System.Windows.Forms.PictureBox SW28B_pb;
        private System.Windows.Forms.PictureBox SW29B_pb;
        private System.Windows.Forms.PictureBox SW30B_pb;
        private System.Windows.Forms.PictureBox SW31B_pb;
        private System.Windows.Forms.PictureBox SW32B_pb;
        private System.Windows.Forms.PictureBox SW33B_pb;
        private System.Windows.Forms.PictureBox SW34B_pb;
        private System.Windows.Forms.PictureBox SW35B_pb;
        private System.Windows.Forms.PictureBox SW36B_pb;
        private System.Windows.Forms.PictureBox BackGround;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button update_btn;
        private System.Windows.Forms.Label lbl_FWVersion;
        private System.Windows.Forms.GroupBox AllButtonSetting_grpbox;
        private System.Windows.Forms.NumericUpDown check_count_numUpDown;
        private System.Windows.Forms.NumericUpDown smpl_interval_numUpDown;
        private System.Windows.Forms.Label lbl_delay_calc_result;
        private System.Windows.Forms.Label lbl_delay_calc;
        private System.Windows.Forms.Label check_count_lbl;
        private System.Windows.Forms.Label check_count_desc_lbl;
        private System.Windows.Forms.Label smpl_interval_lbl;
        private System.Windows.Forms.Label smpl_interval_desc_lbl;
    }
}

